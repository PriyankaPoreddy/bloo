package uk.ac.tees.w9585141.blooplus.auth;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import uk.ac.tees.w9585141.blooplus.R;

public class ForgotPswrdScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_pswrd_screen);
    }
}